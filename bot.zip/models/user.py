class User:
    id: int
    group: int
    ban: int
    accounts: str

    def __init__(self, info):
        self.id = info.get('id')
        self.group = info.get('group')
        self.ban = info.get('ban')
        self.accounts = info.get('accounts')
