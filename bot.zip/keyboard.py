from telethon import Button

import utils

db = utils.DBManager('database.db')


class Menu:
    @staticmethod
    def get_Reply(user_id):
        user_db = db.users_method.get(user_id)
        base = [
            [Button.text('📥 Создать сессию', resize=True)],
            [Button.text('📪 Активные сессии'), Button.text('👤 Аккаунты')]
        ]
        if user_db.group > 0:
            base.append([Button.text('Админ панель')])
        return base


def stop_action():
    return [
        Button.inline('📝 Отменить действие', data='stop_action')
    ]


def delete_msg():
    return [
        Button.inline('📝 Понял', data='delete_msg')
    ]

