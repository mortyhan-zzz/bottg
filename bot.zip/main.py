import asyncio
import os
import threading
from _thread import start_new_thread

import telethon
from telethon import events, Button
from telethon.tl.types import PeerUser, MessageMediaPhoto
from vk_api import vk_api, VkUpload

import config
import keyboard
import utils

variable = utils.Variable()
db = utils.DBManager('database.db')

bot = telethon.TelegramClient('bot', config.api_id, config.api_hash).start(bot_token=config.bot_token)
bot.parse_mode = 'html'


def get_account_keyboard(user_id, select_payload):
    user_db = db.users_method.get(user_id)
    accounts = user_db.accounts.split(';')
    accounts_new = []
    moment_raw = []
    data = []
    for account in accounts:
        if len(moment_raw) == 3:
            data.append(moment_raw)
            moment_raw = []
        try:
            vkApi = vk_api.VkApi(token=account)
            user = vkApi.get_api().users.get()
            moment_raw.append(Button.inline(f"{user[0]['first_name']} {user[0]['last_name']}",
                                            data=f"{select_payload}{user[0]['id']}"))
            accounts_new.append(account)
        except:
            pass
    user_db.accounts = ';'.join(accounts_new)
    db.users_method.update(user_db)
    if len(moment_raw) != 0:
        data.append(moment_raw)
    return data


@bot.on(events.NewMessage(func=lambda m: m.is_private, incoming=True))
async def event_message(event: events.NewMessage.Event):
    user_id = event.chat_id
    user_db = db.users_method.get(user_id)
    msg = event.message.message
    if user_db.id is None:
        user_db = db.users_method.put(user_id)
    elif user_db.ban == 1:
        return
    action = variable.get_action(user_id)
    if action == 1:
        try:
            variable.set_action(user_id, 0)
            vk_session = vk_api.VkApi(token=msg)
            auth = vk_session.method('users.get', {})
            if db.sessions_method.check(auth[0]['id']):
                variable.set_action(user_id, 0)
                return await bot.send_message(user_id, 'Данный аккаунт уже используется в сессии',
                                              buttons=keyboard.delete_msg())
            await bot.send_message(user_id,
                                   f"⚙️ Успешная авторизация.\n{auth[0]['first_name']} {auth[0]['last_name']} (ID: {auth[0]['id']})\n\n"
                                   f"📨 Введите кол-во циклов повторений", buttons=keyboard.stop_action())
            variable.set_action(user_id, 2)
            variable.set_payload(user_id, '1', msg)
        except Exception as e:
            variable.set_action(user_id, 0)
            await bot.send_message(user_id, f'❌ Ошибка авторизации:\n{e}')
    elif action == 2:
        if not msg.isdigit():
            return await bot.send_message(user_id, '❌ Вы ввели некорректное число, повторите попытку',
                                          buttons=keyboard.stop_action())
        if int(msg) > 10000:
            return await bot.send_message(user_id, '❌ Максимальное количество циклов за одну сессию: 10000',
                                          buttons=keyboard.stop_action())
        variable.set_action(user_id, 3)
        variable.set_payload(user_id, '2', msg)
        await bot.send_message(user_id, '📨 Введите айди альбома, в который будет загружаться фотография',
                               buttons=keyboard.stop_action())
    elif action == 3:
        try:
            if not msg.isdigit():
                return await bot.send_message(user_id, '❌ Вы ввели некорректное число, повторите попытку',
                                              buttons=keyboard.stop_action())
            vkApi = vk_api.VkApi(token=variable.get_payload(user_id, '1')).get_api()
            user_vk = vkApi.users.get()
            albums_vk = vkApi.photos.getAlbums(owner_id=user_vk[0]['id'], album_ids=int(msg))
            if albums_vk['count'] == 0:
                return await bot.send_message(user_id, '❌ Указанный Вами альбом не существует, повторите попытку',
                                              buttons=keyboard.stop_action())
            variable.set_action(user_id, 4)
            variable.set_payload(user_id, '3', msg)
            await bot.send_message(user_id, '📨 Отправьте фотографию, которая будет загружаться в альбом',
                                   buttons=keyboard.stop_action())
        except Exception as e:
            variable.set_action(user_id, 0)
            await bot.send_message(user_id, f'❌ Ошибка авторизации:\n{e}')
    elif action == 4:
        if not isinstance(event.media, MessageMediaPhoto):
            return await bot.send_message(user_id, f'❌ Вы отправили некорректное фото, повторите попытку',
                                          buttons=keyboard.stop_action())
        if event.media.photo.sizes[2].size > 100000:
            return await bot.send_message(user_id, f'❌ Вы отправили слишком большое фото, повторите попытку',
                                          buttons=keyboard.stop_action())
        try:
            vkApi = vk_api.VkApi(token=variable.get_payload(user_id, '1')).get_api()
            user_vk = vkApi.users.get()
            repeat = variable.get_payload(user_id, '2')
            album = variable.get_payload(user_id, '3')
            photo = await event.message.download_media()
            db.sessions_method.put(user_id, repeat, variable.get_payload(user_id, '1'), album, photo, user_vk[0]['id'])
            variable.set_action(user_id, 0)
            await bot.send_message(user_id, '✅ Вы успешно создали новую сессию')
        except Exception as e:
            variable.set_action(user_id, 0)
            await bot.send_message(user_id, f'❌ Ошибка авторизации:\n{e}')
    elif action == 5:
        variable.set_action(user_id, 0)
        id1 = 0
        try:
            vk_session = vk_api.VkApi(token=msg)
            auth = vk_session.method('users.get', {})
            id1 = auth[0]['id']
        except Exception as e:
            return await bot.send_message(user_id, f'❌ Ошибка авторизации:\n{e}')
        accounts = user_db.accounts.split(';')
        for account in accounts:
            try:
                vk_session1 = vk_api.VkApi(token=account)
                auth1 = vk_session1.method('users.get', {})
                if str(auth1[0]['id']) == str(id1):
                    return await bot.send_message(user_id, '❌ Данный аккаунт уже присутствует в Вашем списке',
                                                  buttons=keyboard.stop_action())
            except Exception:
                pass
        accounts.append(msg)
        user_db.accounts = ';'.join(accounts)
        db.users_method.update(user_db)
        await bot.send_message(user_id, '✅ Вы успешно добавили новый аккаунт')
    elif action == 6:
        variable.set_action(user_id, 0)
        doc = None
        if event.media is not None:
            doc = await event.message.download_media()
            for user in db.users_method.get_all():
                await bot.send_file(user.id, doc, caption=msg)
            path = os.path.join(os.path.abspath(os.path.dirname(__file__)), doc)
            os.remove(path)
        else:
            for user in db.users_method.get_all():
                await bot.send_message(user.id, msg)
        await bot.send_message(user_id, 'успешно')


@bot.on(events.NewMessage(pattern='/start', func=lambda m: m.is_private, incoming=True))
async def event_start(event: events.NewMessage.Event):
    user_id = event.chat_id
    user_entity = await bot.get_entity(PeerUser(int(user_id)))
    user_db = db.users_method.get(user_id)
    if user_db.ban == 1 or variable.get_action(user_db) != 0:
        return
    await bot.send_message(user_id, f'☺️ Привет, {user_entity.first_name}!',
                           buttons=keyboard.Menu.get_Reply(user_id))


@bot.on(events.CallbackQuery(func=lambda e: e.data.decode().startswith('sel_acc_')))
async def sel_acc(event: events.CallbackQuery.Event):
    user_id = event.sender_id
    user_db = db.users_method.get(user_id)
    if user_db.ban == 1:
        return
    element = event.data.decode().replace('sel_acc_', '')
    accounts = user_db.accounts.split(';')
    token = None
    for account in accounts:
        try:
            vk_session1 = vk_api.VkApi(token=account)
            auth1 = vk_session1.method('users.get', {})
            if str(auth1[0]['id']) == str(element):
                token = account
        except Exception:
            pass

    try:
        variable.set_action(user_id, 0)
        vk_session = vk_api.VkApi(token=token)
        auth = vk_session.method('users.get', {})
        if db.sessions_method.check(auth[0]['id']):
            variable.set_action(user_id, 0)
            return await event.edit('Данный аккаунт уже используется в сессии', buttons=keyboard.delete_msg())
        await event.edit(
            f"⚙️ Успешная авторизация.\n{auth[0]['first_name']} {auth[0]['last_name']} (ID: {auth[0]['id']})\n\n"
            f"📨 Введите кол-во циклов повторений", buttons=keyboard.stop_action())
        variable.set_action(user_id, 2)
        variable.set_payload(user_id, '1', token)
    except Exception as e:
        variable.set_action(user_id, 0)
        await event.edit(user_id, f'❌ Ошибка авторизации:\n{e}')


@bot.on(events.CallbackQuery(data='rassilka'))
async def rassilka(event: events.CallbackQuery.Event):
    user_id = event.sender_id
    user_db = db.users_method.get(user_id)
    if variable.get_action(user_id) != 0 or user_db.ban == 1:
        return
    variable.set_action(user_id, 6)
    await bot.send_message(user_id, 'Введите текст, который хотите разослать',
                           buttons=keyboard.stop_action())


@bot.on(events.NewMessage(pattern='Админ панель', func=lambda m: m.is_private, incoming=True))
async def event_start(event: events.NewMessage.Event):
    user_id = event.chat_id
    user_entity = await bot.get_entity(PeerUser(int(user_id)))
    user_db = db.users_method.get(user_id)
    if user_db.group == 0 or variable.get_action(user_db) != 0:
        return
    await bot.send_message(user_id, 'Панель админа',
                           buttons=[
                               [Button.inline('Сделать рассылку', data='rassilka')]
                           ])


@bot.on(events.NewMessage(pattern='📥 Создать сессию', func=lambda m: m.is_private, incoming=True))
async def event_start(event: events.NewMessage.Event):
    user_id = event.chat_id
    user_entity = await bot.get_entity(PeerUser(int(user_id)))
    user_db = db.users_method.get(user_id)
    if user_db.ban == 1 or variable.get_action(user_db) != 0:
        return
    if len(db.sessions_method.get(user_id)) == 3:
        return await bot.send_message('❌ У Вас запущено максимальное кол-во сессий')
    variable.set_action(user_id, 1)
    data = get_account_keyboard(user_id, f'sel_acc_')
    data.append(keyboard.stop_action())
    await bot.send_message(user_id, '📨 Введите токен ВК\nПолучить здесь: https://bit.ly/2KMjbPk',
                           buttons=data)


@bot.on(events.NewMessage(pattern='📪 Активные сессии', func=lambda m: m.is_private, incoming=True))
async def event_start(event: events.NewMessage.Event):
    user_id = event.chat_id
    user_entity = await bot.get_entity(PeerUser(int(user_id)))
    user_db = db.users_method.get(user_id)
    if user_db.ban == 1 or variable.get_action(user_db) != 0:
        return
    sessions = db.sessions_method.get(user_id)
    if len(sessions) == 0:
        return await bot.send_message(user_id, 'У Вас отсутствует запущенные сессии')
    data = [[]]
    for session in sessions:
        vkApi = vk_api.VkApi(token=session.token)
        user = vkApi.get_api().users.get()
        data[0].append(Button.inline(f'{user[0]["first_name"]} {user[0]["last_name"]}', data=f'info_{session.id}'))
    print(data)
    await bot.send_message(user_id, 'Ваши активные сессии', buttons=data)


@bot.on(events.NewMessage(pattern='👤 Аккаунты', func=lambda m: m.is_private, incoming=True))
async def accounts(event: events.NewMessage.Event):
    user_id = event.chat_id
    user_entity = await bot.get_entity(PeerUser(int(user_id)))
    user_db = db.users_method.get(user_id)
    if user_db.ban == 1 or variable.get_action(user_db) != 0:
        return
    try:
        data = get_account_keyboard(user_id, 'del_acc_')
        data.append([Button.inline('Добавить аккаунт', data='add_acc')])
        await bot.send_message(user_id, 'Чтобы удалить аккаунт нажмите по нему',
                               buttons=data)
    except Exception as e:
        print(e)


@bot.on(events.CallbackQuery(data='add_acc'))
async def add_acc(event: events.CallbackQuery.Event):
    user_id = event.sender_id
    user_db = db.users_method.get(user_id)
    if variable.get_action(user_id) != 0 or user_db.ban == 1:
        return
    variable.set_action(user_id, 5)
    await bot.send_message(user_id, '📨 Введите токен ВК\nПолучить здесь: https://bit.ly/2KMjbPk',
                           buttons=keyboard.stop_action())


@bot.on(events.CallbackQuery(func=lambda e: e.data.decode().startswith('del_acc_')))
async def del_acc(event: events.CallbackQuery.Event):
    user_id = event.sender_id
    user_db = db.users_method.get(user_id)
    if variable.get_action(user_id) != 0 or user_db.ban == 1:
        return
    element = event.data.decode().replace('del_acc_', '')
    accounts = user_db.accounts.split(';')

    token = ''
    for account in accounts:
        try:
            vkApi = vk_api.VkApi(token=account)
            user = vkApi.get_api().users.get()
            if str(user[0]['id']) == str(element):
                token = account
        except:
            pass

    accounts.remove(token)
    user_db.accounts = ';'.join(accounts)
    db.users_method.update(user_db)
    try:
        data = get_account_keyboard(user_id, 'del_acc_')
        data.append([Button.inline('Добавить аккаунт', data='add_acc')])
        await event.edit('Чтобы удалить аккаунт нажмите по нему',
                         buttons=data)
    except Exception as e:
        print(e)


@bot.on(events.CallbackQuery(func=lambda e: e.data.decode().startswith('info_')))
async def info_session(event: events.CallbackQuery.Event):
    user_id = event.sender_id
    user_db = db.users_method.get(user_id)
    if variable.get_action(user_id) != 0 or user_db.ban == 1:
        return
    element = event.data.decode().replace('info_', '')
    session = None
    for sessions in db.sessions_method.get(user_id):
        if str(sessions.id) == str(element):
            session = sessions
            break
    if session is None:
        return
    vkApi = vk_api.VkApi(token=session.token)
    user = vkApi.get_api().users.get()
    await event.edit(f'Информация о сессии "{user[0]["first_name"]} {user[0]["last_name"]}":\n'
                     f'Осталось циклов: {session.repeat}',
                     buttons=[
                         [Button.inline('Остановить сессию', data=f'stops_{session.id}')],
                         [Button.inline('Назад', data='back_sessions')]
                     ])


@bot.on(events.CallbackQuery(func=lambda e: e.data.decode().startswith('stops_')))
async def stop_session(event: events.CallbackQuery.Event):
    user_id = event.sender_id
    user_db = db.users_method.get(user_id)
    if variable.get_action(user_id) != 0 or user_db.ban == 1:
        return
    element = event.data.decode().replace('stops_', '')
    session = None
    for sessions in db.sessions_method.get(user_id):
        if str(sessions.id) == str(element):
            session = sessions
            break
    if session is None:
        user_id = event.chat_id
        user_db = db.users_method.get(user_id)
        if user_db.ban == 1 or variable.get_action(user_db) != 0:
            return
        sessions = db.sessions_method.get(user_id)
        if len(sessions) == 0:
            return await event.edit('У Вас отсутствует запущенные сессии')
        data = [[]]
        for session in sessions:
            vkApi = vk_api.VkApi(token=session.token)
            user = vkApi.get_api().users.get()
            data[0].append(Button.inline(f'{user[0]["first_name"]} {user[0]["last_name"]}', data=f'info_{session.id}'))
        print(data)
        await event.edit('Ваши активные сессии', buttons=data)
        return
    db.sessions_method.delete(session)
    await event.edit('Вы успешно остановили сессию', buttons=[Button.inline('Назад', data='back_sessions')])


@bot.on(events.CallbackQuery(data='back_sessions'))
async def back_sessions(event: events.CallbackQuery.Event):
    user_id = event.chat_id
    user_db = db.users_method.get(user_id)
    if user_db.ban == 1 or variable.get_action(user_db) != 0:
        return
    sessions = db.sessions_method.get(user_id)
    if len(sessions) == 0:
        return await event.edit('У Вас отсутствует запущенные сессии')
    data = [[]]
    for session in sessions:
        vkApi = vk_api.VkApi(token=session.token)
        user = vkApi.get_api().users.get()
        data[0].append(Button.inline(f'{user[0]["first_name"]} {user[0]["last_name"]}', data=f'info_{session.id}'))
    print(data)
    await event.edit('Ваши активные сессии', buttons=data)


@bot.on(events.CallbackQuery(data='stop_action'))
async def stop_action(event: events.CallbackQuery.Event):
    variable.set_action(event.chat_id, 0)
    await event.edit('Действие было отменено', buttons=keyboard.delete_msg())


@bot.on(events.CallbackQuery(data='delete_msg'))
async def stop_action(event: events.CallbackQuery.Event):
    await event.delete()


loop = asyncio.get_event_loop()


async def repeat(interval, func, *args, **kwargs):
    """Run func every interval seconds.

    If func has not finished before *interval*, will run again
    immediately when the previous iteration finished.

    *args and **kwargs are passed as the arguments to func.
    """
    while True:
        await asyncio.gather(
            func(*args, **kwargs),
            asyncio.sleep(interval),
        )


def thread_ok(vkApi, photo, album):
    try:
        upload = VkUpload(vkApi)
        s = upload.photo(photos=photo, album_id=album)
    except:
        print('error | mb flood control')


async def session_func():
    sessions = db.sessions_method.get_all()
    for session in sessions:
        try:
            vkApi = vk_api.VkApi(token=session.token)
            if session.repeat == 0:
                user = vkApi.get_api().users.get()
                await bot.send_message(session.user_id,
                                       f'✅ Сессия "{user[0]["first_name"]} {user[0]["last_name"]}" была завершена')
                path = os.path.join(os.path.abspath(os.path.dirname(__file__)), session.photo)
                os.remove(path)
                db.sessions_method.delete(session)
                continue
            session.repeat -= 1
            db.sessions_method.update(session)
            threading.Thread(target=thread_ok, args=(vkApi, session.photo, session.album)).start()
        except Exception as e:
            db.sessions_method.delete(session)
            path = os.path.join(os.path.abspath(os.path.dirname(__file__)), session.photo)
            os.remove(path)
            await bot.send_message(session.user_id, f'❌ Одна из Ваших сессий была завершена с ошибкой\n{e}')


async def main():
    t1 = asyncio.ensure_future(repeat(0.5, session_func))
    await t1


loop.run_until_complete(main())

bot.run_until_disconnected()
