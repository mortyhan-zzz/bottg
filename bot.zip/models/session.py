class Session:
    id: int
    user_id: int
    repeat: int
    token: str
    photo: str
    album: int
    vk_id: int

    def __init__(self, info):
        self.id = info.get('id')
        self.user_id = info.get('user_id')
        self.repeat = info.get('repeat')
        self.token = info.get('token')
        self.photo = info.get('photo')
        self.album = info.get('album')
        self.vk_id = info.get('vk_id')
