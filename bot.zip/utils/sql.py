import sqlite3

from models import Session
from models.user import User


class users_class:
    def __init__(self, database):
        self._conn = sqlite3.connect(database)

    def get_all(self):
        try:
            data_users = []
            cursor = self._conn.cursor()
            cursor.execute("SELECT * FROM `users`")
            data = cursor.fetchall()
            cursor.close()
            for user in data:
                data_users.append(User({
                    'id': user[0],
                    'group': user[1],
                    'ban': user[2],
                    'accounts': user[3]
                }))
            return data_users
        except sqlite3.OperationalError:
            return []

    def get(self, user_id):
        try:
            cursor = self._conn.cursor()
            cursor.execute("SELECT * FROM `users` WHERE `users`.`id` = {}".format(user_id))
            user = cursor.fetchone()
            cursor.close()
            if user is None:
                return User({})
            return User({
                'id': user[0],
                'group': user[1],
                'ban': user[2],
                'accounts': user[3]
            })
        except sqlite3.OperationalError:
            return User({})

    def update(self, user: User):
        cursor = self._conn.cursor()
        cursor.execute(
            f"UPDATE `users` SET `group` = {user.group}, `ban` = {user.ban}, `accounts` = '{user.accounts}' WHERE `users`.`id` = {user.id};")
        self._conn.commit()
        cursor.close()

    def put(self, user_id):
        cursor = self._conn.cursor()
        cursor.execute(
            f"INSERT OR REPLACE INTO `users` (`id`, `group`, `ban`, `accounts`) VALUES (?, ?, ?, ?)",
            (user_id, 0, 0, ''))
        self._conn.commit()
        cursor.close()
        return self.get(user_id)


class sessions_class:
    def __init__(self, database):
        self._conn = sqlite3.connect(database)

    def check(self, vk_id):
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM `sessions` WHERE `sessions`.`vk_id` = {}".format(vk_id))
        data = cursor.fetchall()
        cursor.close()
        if len(data) != 0:
            return True
        return False

    def get_all(self):
        try:
            data_sessions = []
            cursor = self._conn.cursor()
            cursor.execute("SELECT * FROM `sessions`")
            data = cursor.fetchall()
            cursor.close()
            for session in data:
                data_sessions.append(Session({
                    'id': session[0],
                    'user_id': session[1],
                    'repeat': session[2],
                    'token': session[3],
                    'photo': session[4],
                    'album': session[5],
                    'vk_id': session[6]
                }))
            return data_sessions
        except sqlite3.OperationalError:
            return []

    def get(self, user_id):
        print('ok')
        try:
            cursor = self._conn.cursor()
            cursor.execute("SELECT * FROM `sessions` WHERE `sessions`.`user_id` = {}".format(user_id))
            sessions = cursor.fetchall()
            cursor.close()
            data = []
            for session in sessions:
                data.append(Session({
                    'id': session[0],
                    'user_id': session[1],
                    'repeat': session[2],
                    'token': session[3],
                    'photo': session[4],
                    'album': session[5],
                    'vk_id': session[6]
                }))
            return data
        except sqlite3.OperationalError:
            return []

    def delete(self, session: Session):
        cursor = self._conn.cursor()
        cursor.execute(
            f"DELETE FROM `sessions` WHERE `sessions`.`id` = {session.id};")
        self._conn.commit()
        cursor.close()

    def update(self, session: Session):
        cursor = self._conn.cursor()
        cursor.execute(
            f"UPDATE `sessions` SET `repeat` = {session.repeat} WHERE `sessions`.`id` = {session.id};")
        self._conn.commit()
        cursor.close()

    def put(self, user_id, repeat, token, album, photo, vk_id):
        cursor = self._conn.cursor()
        cursor.execute(
            f"INSERT OR REPLACE INTO `sessions` (`id`, `user_id`, `repeat`, `token`, `photo`, `album`, `vk_id`) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (None, user_id, repeat, token, photo, album, vk_id))
        self._conn.commit()
        cursor.close()


class DBManager:
    users_method: users_class
    sessions_method: sessions_class

    def __init__(self, database):
        self._conn = sqlite3.connect(database)
        self.users_method = users_class(database)
        self.sessions_method = sessions_class(database)
