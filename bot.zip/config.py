bot_token = '1423314289:AAHmZTCxdP_TOB-DIl5X_JwcQv2hooPhKrI'
api_id = 988074
api_hash = 'a5ec8b7b6dbeedc2514ca7e4ba200c13'
